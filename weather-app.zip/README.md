
# 🌦️ Weather App

A simple weather app built with Next.js that lets you search weather by city, view details, and save favorite locations.

## 🚀 Features
- Search city weather
- Show temperature, humidity, wind speed, condition
- Save favorite cities
- Responsive UI

## 🛠️ Tech Stack
- Next.js
- OpenWeatherMap API

## 📂 Folder Structure
See project files.

## ▶️ How to Run
1. Clone repo
2. Install dependencies with `npm install`
3. Add your API key in `.env`
4. Run project with `npm run dev`
