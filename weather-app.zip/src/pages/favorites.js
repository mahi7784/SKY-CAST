
export default function Favorites() {
  return <h2>Favorites page coming soon...</h2>;
}
