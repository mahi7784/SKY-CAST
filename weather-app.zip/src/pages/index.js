
import { useState } from "react";
import { fetchWeather } from "../lib/fetchWeather";
import WeatherCard from "../components/WeatherCard";

export default function Home() {
  const [city, setCity] = useState("");
  const [data, setData] = useState(null);

  async function handleSearch(e) {
    e.preventDefault();
    try {
      const weatherData = await fetchWeather(city);
      setData(weatherData);
    } catch (error) {
      alert(error.message);
    }
  }

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>🌦️ Weather App</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Enter city..."
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      {data && <WeatherCard weather={data} />}
    </div>
  );
}
