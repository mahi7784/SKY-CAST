
export default function WeatherCard({ weather }) {
  return (
    <div style={{ marginTop: "1rem", padding: "1rem", border: "1px solid #ccc" }}>
      <h2>{weather.name}</h2>
      <p>🌡️ Temp: {weather.main.temp} °C</p>
      <p>💧 Humidity: {weather.main.humidity}%</p>
      <p>🌬️ Wind: {weather.wind.speed} m/s</p>
      <p>☁️ Condition: {weather.weather[0].description}</p>
    </div>
  );
}
